<template>
  <div class="container">
    <header>
      <div class="drop" @click="setActive">
        <a href="#" class="toggle-button">
          <span class="bar"></span>
          <span class="bar"></span>
          <span class="bar"></span>
        </a>
      </div>
      <div class="dropnav" :class="{ 'active': isVisibleMobileMenu }">
        <ul>
          <li><a href="#">ورود</a></li>
          <li><a href="#">ثبت نام</a></li>
          <li><a href="#">سوالات متداول</a></li>
          <li><a href="#">قوانین و مقررات</a></li>
          <li><a href="#">تماس با ما</a></li>
          <li><a href="#">خانه</a></li>
          <li><a href="#">خرید و فروش</a></li>
          <li><a href="#">ارز ها</a></li>
          <li><a href="#">محصولات</a></li>
          <li><a href="#">وبلاگ</a></li>
          <li><a href="#">آموزش</a></li>
        </ul>
      </div>
      <div class="mainnav">
        <div class="row">
          <div class="navbar flex">
            <div class="col-lg-8 col-md-7 col-sm-6 col-xs-6">
              <nav class="toppest">
                <ul>
                  <li><a href="#">سوالات متداول</a></li>
                  <li><a href="#">قوانین و مقررات</a></li>
                  <li><a href="#">تماس با ما</a></li>
                </ul>
              </nav>
              <hr class="first">
            </div>
            <div class="col-lg-4 col-md-5 col-sm-6 col-xs-6">
              <nav class="auth">
                <ul>
                  <li><a href="#">ورود</a></li>
                  <li><p>|</p></li>
                  <li><a href="#">ثبت نام</a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 navbar flex dif">
            <nav>
              <ul>
                <li><img class="logopng" src="~/assets/images/Arzypto_logo.png" /></li>
                <li><a href="#">خانه</a></li>
                <li><a href="#">خرید و فروش</a></li>
                <li><a href="#">ارز ها</a></li>
                <li><a href="#">محصولات</a></li>
                <li><a href="#">وبلاگ</a></li>
                <li><a href="#">آموزش</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
    <section>
      <div class="row">
        <div class="col-lg-5 col-md-5 col-sm-7 col-xs-12">
          <div class="showcase-text showcase">
            <h1>8 ارز سود آور</h1>
            <h4>در سال 2021</h4>
            <p>اصلاح 50% بازار ارز دیجیتال، فرصتی برای سوار شدن بر قطار آینده اقتصاد دنیا است.</p>
            <p>بیت کوین به عنوان پدر ارز های دیجیتال و اتریوم به عنوان ملکه ، ارز هایی هستند که توجه زیادی به آنها میشود.اما پروژه هایی در حال خلق شدن هستند که آینده دنیا را تحت تاثیر قرار خواهند داد.</p>
            <span><a class="btn" href="#">خواندن ادامه مطلب</a><svg xmlns="http://www.w3.org/2000/svg" width="74" height="14" viewBox="0 0 74 14">
              <g id="Group_9949" data-name="Group 9949" transform="translate(-1442 -709)">
                <circle id="Ellipse_96" data-name="Ellipse 96" cx="7" cy="7" r="7" transform="translate(1502 709)" fill="#e1e1e1"/>
                <circle id="Ellipse_97" data-name="Ellipse 97" cx="7" cy="7" r="7" transform="translate(1472 709)" fill="#e1e1e1"/>
                <circle id="Ellipse_98" data-name="Ellipse 98" cx="7" cy="7" r="7" transform="translate(1442 709)" fill="#e1e1e1"/>
              </g>
            </svg></span>
          </div>
        </div>
        <div class="col-lg-7 col-md-7 col-sm-5 col-xs-12 imag">
          <img class="blue" src="~/assets/images/bgShape.png" alt="blue" />
          <img class="bg" src="~/assets/images/bg.png" alt="blue" />
        </div>
      </div>
    </section>
    <section>
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mou">
        <img class="mouse" src="~/assets/images/mouse.svg" alt="mouse" />
      </div>
    </section>
    <section>
      <div class="row maincont mainc">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="maincont-heading">
            <h1>8 ارز دیجیتال که حتما باید بخریم</h1>
            <h3>تا سود انفجاری داشته باشیم !!</h3>
          </div>
          <div class="maincont-text">
            <p>اصلاح ۵۰% بازار ارز دیجیتال، فرصتی برای سوار شدن بر قطار آینده اقتصاد دنیا است.</p>
            <p>بیت کوین بعنوان پدر ارزهای دیجیتال و اتریوم بعنوان ملکه، ارزهایی هستند که توجه زیادی به آنها می شود. اما پروژه هایی در حال خلق شدند هستند که آینده دنیا را تحت تاثیر قرار می دهند
            زمانی را بیاد بیاورید که کارت های بانکی تازه به بازار آمده بود، افراد سنتی و محافظه کار داشتن پول نقد را ترجیح می دادند. امروزه تقریبا پول نقد جایگاه خود را از دست داده همه اقشار جامعه
            .از کارت های بانکی استفاده می کنند</p>
            <p>این واقعیت برای ارزهای دیجیتال هم صادق است. زمانی خواهد رسید که پولهای کاغذی اعتبار خود را از دست داده و ارزهای دیجیتال جایگزین آنها شده اند.</p>
            <p>اکنون زمان مناسبی برای سرمایه گذاری در ارزهای دیجیتال بر اساس بودجه شما است. در اینجا راهنمایی آورده شده است که به شما کمک میکند بدانید کدام یک از پروژه ها در حال حاضر برای
            سرمایه گذاری بهتر هستند.</p>  
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="row maincont maincont-left">
        <div class="col-lg-7 col-md-7 col-sm-9 col-xs-12">
          <div class="maincont-title">
            <h1>Ve-Chain</h1>
            <hr>
            <p> اگر واقعا به دنبال ارز رمزپایه ارزان هستید، ویچین ممکن است توجه شما را جلب کند</p>
            <p>تخصص ويچین مدیریت زنجیره تامین است. به عنوان مثال در آینده ای نچندان دور شرکتهای مهم یک کد.
              را در محصولات خود قرار میدهند و شما با استفاده از فناوری ویچین تنها با یک اسکن ساده می توانید QR
              اجناس تقلبی را از اصلی تشخیص بدهید. از قطعات خودرو گرفته تا اجناس لوکس، محصولات کشاورزی و یا
              حتی دارویی.</p>
            <p>و حتى (dApps) از آنجا که ویچین با قراردادهای هوشمند سازگار است، امکان ایجاد برنامه های غیرمتمرکز توکن های جدید در بلاکچین آن وجود دارد.</p>
            <p>
              نرخ سود سالانه این کوین ارزشمند ۷۹۸% بوده که آن را در رتبه ۱۵ بازار قرار داده و نشان از جذابیت بالا
              .ایده های جاه طلبانه ی آن دارد.</p>
          </div>
        </div>
        <div class="col-lg-5  col-md-5 col-sm-3 col-xs-12">
          <div class="maincont-log">
            <img src="../assets/images/vechain.png" alt="Ve-Chain" />
            <a href="#"><img class="percen" src="../assets/images/percent.svg" alt="percen" />دریافت کد تخفیف VeChain</a>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="row maincont maincont-right">
        <div class="col-lg-5 col-md-5 col-sm-3 col-xs-12">
          <div class="maincont-log">
            <img src="../assets/images/cardano.png" alt="cardano" />
            <a href="#"><img class="percen" src="../assets/images/percent.svg" alt="percen" />دریافت کد تخفیف Cardano</a>
          </div>
        </div>
        <div class="col-lg-7  col-md-7 col-sm-9 col-xs-12">
          <div class="maincont-title">
            <h1>CARDANO</h1>
            <hr>
            <p>کاردانو شبکه ای است که به آن لقب کشنده اتریوم داده شده است. به دلیل مشکلات زیاد اتریوم، یکی از
              .بناینگذارنش به نام چارلز هاسکينسون از این تیم جدا شد و بلاکچین بینظیر خود را بوجود آورد.</p>
            <p>
              شبکه ای با سرعت تراکنش بالا، منعطف با شرایط گوناگون، هزینه تراکنش ناچیز، مقیاس پذیری عالی و
              سرعت خیره کننده یک میلیون تراکنش در ثانیه، پروژه ای است که آمده تا آینده ای متفاوت را برای بشریت
              رقم بزند. کاردانو خود را پرچم دار نسل سوم بلاکچین میداند، نسلی که تمام مشکلات قبلی خود را از حل
            </p>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="row maincont maincont-left">
        <div class="col-lg-7 col-md-7 col-sm-9 col-xs-12">
          <div class="maincont-title">
            <h1>Chiliz</h1>
            <hr>
            <p>کاردانو شبکه ای است که به آن لقب کشنده اتریوم داده شده است. به دلیل مشکلات زیاد اتریوم، یکی از
              .بناینگذارنش به نام چارلز هاسکينسون از این تیم جدا شد و بلاکچین بینظیر خود را بوجود آورد</p>
            <p>
              شبکه ای با سرعت تراکنش بالا، منعطف با شرایط گوناگون، هزینه تراکنش ناچیز، مقیاس پذیری عالی و
              سرعت خیره کننده یک میلیون تراکنش در ثانیه، پروژه ای است که آمده تا آینده ای متفاوت را برای بشریت
              رقم بزند. کاردانو خود را پرچم دار نسل سوم بلاکچین میداند، نسلی که تمام مشکلات قبلی خود را از حل
            </p>
          </div>
        </div>
        <div class="col-lg-5  col-md-5 col-sm-3 col-xs-12">
          <div class="maincont-log">
            <img src="../assets/images/chiliz.png" alt="chiliz" />
            <a href="#"><img class="percen" src="../assets/images/percent.svg" alt="percen" />دریافت کد تخفیف VeChain</a>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="row maincont maincont-right">
        <div class="col-lg-5 col-md-5 col-sm-3 col-xs-12">
          <div class="maincont-log">
            <img src="../assets/images/dogecoin.png" alt="dogecoin" />
            <a href="#"><img class="percen" src="../assets/images/percent.svg" alt="percen" />دریافت کد تخفیف Cardano</a>
          </div>
        </div>
        <div class="col-lg-7  col-md-7 col-sm-9 col-xs-12">
          <div class="maincont-title">
            <h1>Dogecoin</h1>
            <hr>
            <p> اگر واقعا به دنبال ارز رمزپایه ارزان هستید، ویچین ممکن است توجه شما را جلب کند</p>
            <p>تخصص ويچین مدیریت زنجیره تامین است. به عنوان مثال در آینده ای نچندان دور شرکتهای مهم یک کد.
              را در محصولات خود قرار میدهند و شما با استفاده از فناوری ویچین تنها با یک اسکن ساده می توانید QR
              اجناس تقلبی را از اصلی تشخیص بدهید. از قطعات خودرو گرفته تا اجناس لوکس، محصولات کشاورزی و یا
              حتی دارویی.</p>
            <p>و حتى (dApps) از آنجا که ویچین با قراردادهای هوشمند سازگار است، امکان ایجاد برنامه های غیرمتمرکز توکن های جدید در بلاکچین آن وجود دارد.</p>
            <p>
              نرخ سود سالانه این کوین ارزشمند ۷۹۸% بوده که آن را در رتبه ۱۵ بازار قرار داده و نشان از جذابیت بالا
              .ایده های جاه طلبانه ی آن دارد.</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isVisibleMobileMenu: false
    }
  },
  methods: {
    setActive() {
      this.isVisibleMobileMenu = !this.isVisibleMobileMenu
    }
  }
}
</script>

<style lang="scss">


</style>
